# 履歷單一資料來源系統

網站與 PDF 共用同一份資料，改一處、兩邊同步。

## 結構

```
resume-system/
├── data/
│   └── resume.json          ← 唯一需要維護的內容檔
├── scripts/
│   └── build-pdf.mjs        ← PDF 產生腳本（含 A4 模板）
└── public/
    ├── resume-print.html    ← 產生的中繼 HTML（可用瀏覽器預覽排版）
    └── resume.pdf           ← 最終輸出
```

## 使用方式（在你的 Mac 上）

1. 將 `data/` 與 `scripts/` 兩個資料夾放進你的 Vue 專案根目錄。
2. 第一次使用先安裝 Puppeteer：
   ```bash
   npm install --save-dev puppeteer
   ```
3. 在 `package.json` 的 scripts 加入：
   ```json
   "build:pdf": "node scripts/build-pdf.mjs"
   ```
4. 之後每次更新內容：改 `data/resume.json` → 執行 `npm run build:pdf`
   → `public/resume.pdf` 就會更新，網站的「下載履歷 PDF」按鈕指向 `/resume.pdf` 即可。

## resume.json 待補欄位

- `contact` 裡的 **email** 與 **LinkedIn** 目前是佔位文字（含「請填入」字樣），
  腳本會自動略過未填的項目，填好後會自動出現在 PDF 頁首。
- `phone` 的 `"pdfOnly": true` 欄位是保留給網站端用的：之後改造 Vue 元件時，
  標記為 pdfOnly 的聯絡方式只會出現在 PDF、不會顯示在公開網站上（保護隱私）。

## 與網站同步（下一步）

Vue 元件改造成從 `data/resume.json` 讀取資料後（`import resume from '@/data/resume.json'`），
內容就完全單一來源。若使用 GitHub Actions 部署，可在 build 步驟前加入
`npm run build:pdf`，達成 push 後自動更新 PDF、零手動同步。

## 排版調整

PDF 的 A4 模板（含所有樣式）都在 `scripts/build-pdf.mjs` 的 `renderHTML()` 裡，
配色沿用網站的深墨藍（#16243A）× 象牙白（#FBFAF7）× 古銅（#96794F）。
執行 `node scripts/build-pdf.mjs --html-only` 可只產生 HTML，
用瀏覽器打開 `public/resume-print.html` 快速預覽、調整樣式後再輸出 PDF。


## 定案配色（2026-07-13）

| 角色 | 色碼 | 用途 |
|------|------|------|
| 柔霧玫瑰 band | `#F5E9EC` | 頁首／收尾色帶 |
| 近白暖底 | `#FDFBFA` | 頁面底色 |
| 暖墨色 | `#332B2F` | 主要文字 |
| 深玫瑰 | `#A24E60` | 強調色（眉標、機構名、按鈕、條列線） |
| 暖灰 | `#6E6066` | 次要文字 |
| 髮絲線 | `#ECDFE2` | 分隔線 |

網站與 PDF 共用此色彩系統。
